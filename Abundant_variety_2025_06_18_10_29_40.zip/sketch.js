let fase = 0; // 0 = Tela inicial, 1 = Fase do Campo, 2 = Fase da Cidade, 3 = Fim
let perguntasCampo, perguntasCidade;
let perguntaAtual, respostaEscolhida;
let score = 0;
let totalPerguntas = 3;

function setup() {
  createCanvas(400, 400);
  textAlign(CENTER, CENTER);
  
  // Definindo as perguntas para o campo
  perguntasCampo = [
    {pergunta: "Qual é o principal produto agrícola do Brasil?", alternativas: ["Café", "Milho", "Arroz"], resposta: 0},
    {pergunta: "Qual é o nome da dança típica do interior?", alternativas: ["Forró", "Samba", "Funk"], resposta: 0},
    {pergunta: "Qual é o animal mais associado à vida rural?", alternativas: ["Cavalo", "Cachorro", "Gato"], resposta: 0},
  ];
  
  // Definindo as perguntas para a cidade
  perguntasCidade = [
    {pergunta: "Qual é o maior centro financeiro do Brasil?", alternativas: ["São Paulo", "Rio de Janeiro", "Brasília"], resposta: 0},
    {pergunta: "Qual é o principal meio de transporte urbano?", alternativas: ["Carro", "Ônibus", "Avião"], resposta: 1},
    {pergunta: "Qual é o maior evento cultural do Brasil?", alternativas: ["Carnaval", "Festa Junina", "Oktoberfest"], resposta: 0},
  ];

  // Selecionando a primeira pergunta do campo
  perguntaAtual = perguntasCampo[0];
}

function draw() {
  background(255);
  textSize(24);
  
  if (fase === 0) {
    text("Bem-vindo ao Desafio do Campo e Cidade!", width / 2, height / 3);
    textSize(18);
    text("Clique para Iniciar", width / 2, height / 2);
  } else if (fase === 1 || fase === 2) {
    mostrarPergunta();
  } else if (fase === 3) {
    textSize(24);
    text("Fim do Jogo!", width / 2, height / 3);
    textSize(18);
    text("Você fez " + score + " pontos.", width / 2, height / 2);
    text("Clique para Jogar Novamente", width / 2, height / 1.5);
  }
}

function mousePressed() {
  if (fase === 0) {
    fase = 1;
    score = 0;
  } else if (fase === 1 || fase === 2) {
    verificarResposta();
  } else if (fase === 3) {
    fase = 1;
    score = 0;
    perguntaAtual = perguntasCampo[0]; // Começar novamente no campo
  }
}

function mostrarPergunta() {
  textSize(18);
  text(perguntaAtual.pergunta, width / 2, height / 4);
  
  // Alternativas
  for (let i = 0; i < perguntaAtual.alternativas.length; i++) {
    text(perguntaAtual.alternativas[i], width / 2, height / 2 + i * 30);
  }
}

function verificarResposta() {
  // Aqui assumimos que a alternativa clicada é a que mais se aproxima do centro
  let resposta = floor((mouseY - height / 2) / 30);
  if (resposta === perguntaAtual.resposta) {
    score++;
  }
  
  // Avançar para a próxima fase
  if (fase === 1) {
    if (score >= totalPerguntas) {
      fase = 2; // Se acertou todas, vai para a cidade
      perguntaAtual = perguntasCidade[0];
    } else {
      perguntaAtual = perguntasCampo[score];
    }
  } else if (fase === 2) {
    if (score >= totalPerguntas) {
      fase = 3; // Se acertou todas na cidade, fim do jogo
    } else {
      perguntaAtual = perguntasCidade[score];
    }
  }
}
